class Preferences {

  static final String ACCESS_TOKEN = "accessToken";
  static final String USER_ID = "user_id";
  static final String USER_NAME = "user_name";
  static final String EMAIL = "email";
  static final String USER_LOGIN = "USER_LOGIN";
}