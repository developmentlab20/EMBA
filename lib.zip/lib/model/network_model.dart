class NetworkModel{
  String name;
  String imageUrl;
  NetworkModel({required this.name,required this.imageUrl});
}