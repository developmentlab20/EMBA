import 'package:flutter/material.dart';

class PeopleNeaarByWidgetScreen extends StatelessWidget {
  const PeopleNeaarByWidgetScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size =MediaQuery.of(context).size;
    return  SizedBox(
      width: size.width,
      child: Column(children: [

      ],),
    );
  }
}
